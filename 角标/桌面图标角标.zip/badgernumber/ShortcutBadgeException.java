package com.mingzhi.testsystemapp.badgernumber;

@Deprecated
public class ShortcutBadgeException extends Exception {
    public ShortcutBadgeException(String message) {
        super(message);
    }
}
