package com.mingzhi.testsystemapp.badgernumber;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mingzhi.testsystemapp.R;
import com.mingzhi.testsystemapp.badgernumber.ShortcutBadger;

public class MainActivity extends Activity {

	private EditText numInput;
	private Context context = this;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_base);

		numInput = (EditText) findViewById(R.id.action_menu_presenter);

		Button button = (Button) findViewById(R.id.btn_get_verify_code);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				int badgeCount = 0;
				try {
					badgeCount = Integer.parseInt(numInput.getText().toString());
				} catch (NumberFormatException e) {
					Toast.makeText(getApplicationContext(), "Error input", Toast.LENGTH_SHORT).show();
				}

				ShortcutBadger.with(getApplicationContext()).count(badgeCount);

				// sendToXiaoMi(badgeCount + "");

				Toast.makeText(getApplicationContext(), "Set count=" + badgeCount, Toast.LENGTH_SHORT).show();
			}
		});

		// find the home launcher Package
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		ResolveInfo resolveInfo = getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
		String currentHomePackage = resolveInfo.activityInfo.packageName;

		TextView textViewHomePackage = (TextView) findViewById(R.id.text2);
		// String string = android.os.Build.BRAND;
		textViewHomePackage.setText("launcher:" + currentHomePackage);
		// textViewHomePackage.setText("launcher:" + string);
		// textViewHomePackage.setText("launcher:" + getPhoneInfo());
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	private String getPhoneInfo() {
		String phoneInfo = "产品名称: " + android.os.Build.PRODUCT + "\n";
		phoneInfo += "CPU型号: " + android.os.Build.CPU_ABI + "\n";
		phoneInfo += "标签: " + android.os.Build.TAGS + "\n";
		phoneInfo += "手机型号: " + android.os.Build.MODEL + "\n";
		phoneInfo += "SDK版本: " + android.os.Build.VERSION.SDK + "\n";
		phoneInfo += "系统版本: " + android.os.Build.VERSION.RELEASE + "\n";
		phoneInfo += "设备驱动: " + android.os.Build.DEVICE + "\n";
		phoneInfo += "显示: " + android.os.Build.DISPLAY + "\n";
		phoneInfo += "品牌: " + android.os.Build.BRAND + "\n";
		phoneInfo += "主板: " + android.os.Build.BOARD + "\n";
		phoneInfo += "指纹: " + android.os.Build.FINGERPRINT + "\n";
		phoneInfo += "ID: " + android.os.Build.ID + "\n";
		phoneInfo += "制造商: " + android.os.Build.MANUFACTURER + "\n";
		phoneInfo += "用户组: " + android.os.Build.USER + "\n";

		return phoneInfo;
	}
}
